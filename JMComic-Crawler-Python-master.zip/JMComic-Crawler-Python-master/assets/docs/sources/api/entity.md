# entity

::: jmcomic.jm_entity
    options:
      inherited_members: true
      members:
      - JmAlbumDetail
      - JmPhotoDetail
      - JmImageDetail
      - JmPageContent
      - JmSearchPage