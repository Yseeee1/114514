# download

::: jmcomic.api
    options:
      members:
      - download_album
      - download_photo
      - create_option
      - create_option_by_env
      - create_option_by_file
      - create_option_by_str
