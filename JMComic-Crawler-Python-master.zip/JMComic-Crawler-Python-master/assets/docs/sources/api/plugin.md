# plugin

::: jmcomic.jm_plugin
    options:
      filters:
      - Plugin$