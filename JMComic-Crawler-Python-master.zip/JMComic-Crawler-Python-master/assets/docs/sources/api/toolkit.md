# toolkit

::: jmcomic.jm_toolkit
    options:
      inherited_members: true
      members:
      - JmcomicText
      - PatternTool
      - JmPageTool
      - JmImageTool
      - JmCryptoTool