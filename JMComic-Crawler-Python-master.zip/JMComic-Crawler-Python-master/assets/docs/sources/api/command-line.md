# command-line

::: jmcomic.cl
    options:
      members:
      - JmcomicUI
