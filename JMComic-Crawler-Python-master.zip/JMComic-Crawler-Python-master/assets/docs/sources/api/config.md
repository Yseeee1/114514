# config

::: jmcomic.jm_config
    options:
      members:
      - JmMagicConstants
      - JmModuleConfig
      - default_jm_logging
         